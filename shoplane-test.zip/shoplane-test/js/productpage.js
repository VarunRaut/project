let root = $("#root");

let productId = location.search.split("=")[1];

$.get(
  "https://5d76bf96515d1a0014085cf9.mockapi.io/product/" + productId,
  function (response) {
    console.log(response);
    productUI(response);
  }
);

function productUI(data) {
  let image = $("<img>");
  image.attr({ src: data.preview, height: "300px" });

  let div = $("<div>");
  div.append(image);
  div.append(data.id, data.name, data.description);
  root.html(div);
}
